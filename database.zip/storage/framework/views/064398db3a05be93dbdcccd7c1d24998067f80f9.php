<?php $__env->startSection('title'); ?>
Admin Panel Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<h4 style="color: black;">
    Sosial Media
</h4>

<div class="row">

    <div class="col-md-8 card p-3">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th scope="col">Logo</th>
                    <th scope="col">Sosmed</th>
                    <th scope="col">Link</th>
                    <th scope="col">Handle</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $sosmed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row">
                        <img class="img-fluid" style="width: 5rem" src="<?php echo e(asset($item->logo)); ?>" alt="">
                    </th>
                    <td style="margin: auto" class="align-middle"><?php echo e($item->nama_sosmed); ?></td>
                    <td style="margin: auto" class="align-middle"><?php echo e($item->link); ?></td>
                    <td class="align-middle">
                        <!-- <a href="<?php echo e(route('admin.delete.sosial_media', $item->id)); ?>">Hapus</a> -->
                        <a href="<?php echo e(route('admin.delete.sosial_media', encrypt($item->id))); ?>" class="btn btn-danger text-white"><i class="fa-sharp fa-solid fa-pen-to-square"></i>
                            Hapus
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div class="col-md-4">
        <form class="card p-3" method="POST" action="<?php echo e(route('admin.sosmed.store')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="exampleInputEmail1">Nama Sosmed</label>
                <input type="text" name="nama_sosmed" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Nama sosmed">
                <?php $__errorArgs = ['nama_sosmed'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label for="exampleInputPassword1">Logo Sosmed</label>
                <input type="file" name="logo" class="form-control" id="exampleInputPassword1">
                <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label for="exampleInputEmail1">Link Sosmed</label>
                <input type="text" name="link" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Masukkan link sosmed">
                <?php $__errorArgs = ['link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yohke\OneDrive - Universitas Atma Jaya Yogyakarta\Kegiatan Univ\Panit Inisiasi 23\inisiasi_uajy23\resources\views/admin/index.blade.php ENDPATH**/ ?>