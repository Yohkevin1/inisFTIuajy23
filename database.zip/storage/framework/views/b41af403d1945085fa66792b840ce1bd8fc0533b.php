<?php $__env->startSection('title'); ?>
Admin Panel Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<h4 style="color: black;">
    Timeline
</h4>

<div class="row">
    <div class="col-md-8 card p-3">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th scope="col">Nama Event</th>
                    <th scope="col">Tanggal Pelaksanaan</th>
                    <th scope="col">Handle</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $timelines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->nama_event); ?></td>
                    <td><?php echo e(date('D, d M Y', strtotime($item->tanggal_pelaksanaan))); ?></td>
                    <td>
                        <!-- <a href="<?php echo e(route('admin.edit.timeline', $item->id)); ?>">Edit</a>
                        <a href="<?php echo e(route('admin.delete.timeline', $item->id)); ?>">Hapus</a> -->
                        <a href="<?php echo e(route('admin.edit.timeline', encrypt($item->id))); ?>" class="btn btn-warning text-white"><i class="fa-sharp fa-solid fa-pen-to-square"></i>
                            Edit
                        </a>
                        <a href="<?php echo e(route('admin.delete.timeline', encrypt($item->id))); ?>" class="btn btn-danger text-white"><i class="fa-sharp fa-solid fa-pen-to-square"></i>
                            Hapus
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>
    <div class="col-md-4">
        <form class="card p-3" method="POST" action="<?php echo e(route('admin.timeline.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="exampleInputEmail1">Date</label>
                <input type="date" name="tanggal_pelaksanaan" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
                <?php $__errorArgs = ['tanggal_pelaksanaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label for="exampleInputPassword1">Nama event</label>
                <input type="text" name="nama_event" class="form-control" id="exampleInputPassword1" placeholder="Nama event">
                <?php $__errorArgs = ['nama_event'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yohke\OneDrive - Universitas Atma Jaya Yogyakarta\Kegiatan Univ\Panit Inisiasi 23\inisiasi_uajy23\resources\views/admin/timeline/index.blade.php ENDPATH**/ ?>