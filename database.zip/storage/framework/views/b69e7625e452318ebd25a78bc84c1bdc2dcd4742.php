<?php $__env->startSection('title'); ?>
Admin Panel Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<h4 style="color: black;">
    Kelompok
</h4>

<div class="container-fluid ">
    <div class="card bg-light mt-3">
        <div class="card-body">
            <form action="<?php echo e(route('users.import')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="file" name="file" class="form-control">
                <br>
                <button class="btn btn-success">Import Data Mahasiswa</button>
            </form>
            <a style="margin: 1rem 0" class="btn btn-primary float-end" href="<?php echo e(route('users.export')); ?>">Export Data Mahasiswa</a>
            <!-- <a style="margin: 1rem 0" class="btn btn-danger float-end" href="<?php echo e(route('mahasiswa.delete.all')); ?>">Delete Data Mahasiswa</a> -->
            <a style="margin: 1rem 0" class="btn btn-danger float-end" href="#" data-bs-toggle="modal" data-bs-target="#confirmDeleteSemuaMahasiswa">Delete Data Mahasiswa</a>
            <table id="table_id" class="display table_bordered mt-3">
                <thead>
                    <tr>
                        <th>NAMA</th>
                        <th>NPM</th>
                        <th>KELOMPOK</th>
                        <th>STATUS LULUS</th>
                        <th>HANDLE</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->nama); ?></td>
                        <td><?php echo e($item->npm); ?></td>
                        <td><?php echo e($item->kelompok); ?></td>
                        <td><?php echo e($item->status_lulus); ?></td>
                        <td>
                            <button class="btn btn-info" data-bs-target="#Ubah<?php echo e($item->id); ?>" data-bs-toggle="modal">
                                Edit
                            </button>
                            <a class="btn btn-danger text-white" href="#Delete<?php echo e($item->id); ?>" data-bs-toggle="modal">
                                Hapus
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="Ubah<?php echo e($item->id); ?>" aria-hidden="true" aria-labelledby="exampleModalToggleLabel<?php echo e($item->id); ?>" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalToggleLabel<?php echo e($item->id); ?>"><?php echo e($item->nama); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form class="card p-3" method="POST" action="<?php echo e(route('mahasiswa.update', encrypt($item->id))); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Nama</label>
                        <input type="text" value="<?php echo e($item->nama); ?>" name="nama" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Masukkan nama">
                        <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">NPM</label>
                        <input type="text" name="npm" class="form-control" id="exampleInputPassword1" value="<?php echo e($item->npm); ?>" placeholder="Masukkan NPM">
                        <?php $__errorArgs = ['npm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Kelompok</label>
                        <input type="text" value="<?php echo e($item->kelompok); ?>" name="kelompok" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Masukkan kelompok">
                        <?php $__errorArgs = ['kelompok'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Status Lulus</label>
                        <select class="form-control" name="status">
                            <option value="-" <?php echo e($item->status_lulus === '-' ? 'selected' : ''); ?>>-</option>
                            <option value="Tidak Lulus" <?php echo e($item->status_lulus === 'Tidak Lulus' ? 'selected' : ''); ?>>Tidak Lulus</option>
                            <option value="Lulus" <?php echo e($item->status_lulus === 'Lulus' ? 'selected' : ''); ?>>Lulus</option>
                        </select>
                        <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <button type="submit" class="btn btn-primary">Update</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!-- Modal Konfirmasi Delete Semua Mahasiswa-->
<div class="modal fade" id="confirmDeleteSemuaMahasiswa" tabindex="-1" aria-labelledby="confirmDeleteModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="confirmDeleteModalLabel">Konfirmasi Hapus Semua Data Mahasiswa</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                Apakah Anda yakin ingin menghapus semua data mahasiswa? Data yang terhapus tidak dapat dikembalikan.
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <a href="<?php echo e(route('mahasiswa.delete.all')); ?>" class="btn btn-danger">Hapus</a>
            </div>
        </div>
    </div>
</div>

<!-- Modal Konfirmasi Delete Mahasiswa-->
<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="Delete<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="confirmDeleteModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="confirmDeleteModalLabel">Konfirmasi Data <?php echo e(explode(' ', $item->nama)[0]); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                Apakah anda yakin ingin menghapus data <?php echo e(explode(' ', $item->nama)[0]); ?>? Data yang terhapus tidak dapat dikembalikan.
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <a href="<?php echo e(route('mahasiswa.delete', encrypt($item->id))); ?>" class="btn btn-danger">Hapus</a>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<script>
    $(document).ready(function() {
        $('#table_id').DataTable();
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yohke\OneDrive - Universitas Atma Jaya Yogyakarta\Kegiatan Univ\Panit Inisiasi 23\inisiasi_uajy23\resources\views/admin/kelompok/kelompok.blade.php ENDPATH**/ ?>