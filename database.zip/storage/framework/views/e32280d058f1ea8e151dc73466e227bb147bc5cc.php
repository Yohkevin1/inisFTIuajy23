<?php $__env->startSection('title'); ?>
    Admin | Inisiasi FTI UAJY 2023
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<h4 style="color: black;">
    Edit <?php echo e($panitia->nama); ?>

</h4>
<div class="row">
    <div class="col-md-7 card p-3">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th scope="col">Foto</th>
                    <th scope="col">Nama</th>
                    <th scope="col">Bidang</th>
                    <th scope="col">Jabatan</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>
                        <img style="max-width: 5rem" src="<?php echo e(asset($panitia->foto)); ?>" alt="">
                    </td>
                    <td class="align-middle"><?php echo e($panitia->nama); ?></td>
                    <td class="align-middle"><?php echo e($panitia->bidang->nama_bidang); ?></td>
                    <td class="align-middle"><?php echo e($panitia->sub_bidang->nama_sub_bidang); ?></td>
                </tr>
            </tbody>
        </table>
    </div>
    <div class="col-md-5">
        <form class="card p-3" method="POST" action="<?php echo e(route('panitia.update', encrypt($panitia->id))); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <select class="form-control" name="bidang_id" id="">
                    <option selected value="<?php echo e($bidang->id); ?>"><?php echo e($bidang->nama_bidang); ?></option>
                </select>
            </div>
            <div class="form-group">
                <select class="form-control" name="sub_bidang_id">
                    <option selected disabled value="">Pilih Sub Menu Bidang</option>
                    <?php $__currentLoopData = $sub_bidang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($sb->id); ?>" <?php echo e(old('sub_bidang_id') == $sb->sub_bidang ? 'selected' : ''); ?>><?php echo e($sb->nama_sub_bidang); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['sub_bidang_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label for="exampleInputEmail1">Nama Lengkap</label>
                <input type="text" name="nama" value="<?php echo e($panitia->nama); ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Masukkan nama">
                <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label for="exampleInputPassword1">Foto</label>
                <input type="file" name="foto" class="form-control" id="exampleInputPassword1" placeholder="Nama event">
                <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
    <div class="mt-3">
        <button class="btn btn-danger" onclick="history.back()">Kembali</button>
    </div>
</div>
<?php $__env->stopSection(); ?>
    
    
<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yohke\OneDrive - Universitas Atma Jaya Yogyakarta\Kegiatan Univ\Panit Inisiasi 23\inisiasi_uajy23\resources\views/admin/panitia/edit.blade.php ENDPATH**/ ?>